-- --------------------------------------------------------
-- 호스트:                          192.168.0.12
-- 서버 버전:                        10.4.6-MariaDB - mariadb.org binary distribution
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- greenright 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `greenright` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `greenright`;

-- 테이블 greenright.baskets 구조 내보내기
CREATE TABLE IF NOT EXISTS `baskets` (
  `member_id` int(11) NOT NULL,
  `option_item_id` int(11) NOT NULL,
  `registered_date` date NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`member_id`,`option_item_id`),
  KEY `FK_option_items_TO_baskets` (`option_item_id`),
  CONSTRAINT `FK_members_TO_baskets` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_option_items_TO_baskets` FOREIGN KEY (`option_item_id`) REFERENCES `option_items` (`option_item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.baskets:~14 rows (대략적) 내보내기
/*!40000 ALTER TABLE `baskets` DISABLE KEYS */;
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(21, 15, '2019-11-26', 1);
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(23, 7, '2019-11-25', 4);
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(23, 8, '2019-11-25', 4);
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(28, 18, '2019-11-25', 5);
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(28, 20, '2019-11-25', 6);
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(28, 21, '2019-11-25', 4);
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(28, 24, '2019-11-25', 3);
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(31, 15, '2019-11-26', 1);
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(31, 70, '2019-11-26', 1);
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(38, 22, '2019-11-26', 1);
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(44, 15, '2019-11-26', 2);
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(44, 23, '2019-11-26', 1);
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(46, 15, '2019-11-26', 2);
INSERT INTO `baskets` (`member_id`, `option_item_id`, `registered_date`, `quantity`) VALUES
	(46, 23, '2019-11-26', 1);
/*!40000 ALTER TABLE `baskets` ENABLE KEYS */;

-- 테이블 greenright.boards 구조 내보내기
CREATE TABLE IF NOT EXISTS `boards` (
  `boards_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `title` varchar(255) NOT NULL,
  `contents` varchar(2000) NOT NULL,
  `vw_count` int(11) DEFAULT NULL,
  PRIMARY KEY (`boards_id`),
  KEY `FK_members_TO_boards` (`member_id`),
  CONSTRAINT `FK_members_TO_boards` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.boards:~11 rows (대략적) 내보내기
/*!40000 ALTER TABLE `boards` DISABLE KEYS */;
INSERT INTO `boards` (`boards_id`, `member_id`, `created_date`, `title`, `contents`, `vw_count`) VALUES
	(1, 1, '2019-11-13', 'asdaf', 'asdasf', 3);
INSERT INTO `boards` (`boards_id`, `member_id`, `created_date`, `title`, `contents`, `vw_count`) VALUES
	(2, 1, '2019-11-13', 'asdasf', 'asdas', 6);
INSERT INTO `boards` (`boards_id`, `member_id`, `created_date`, `title`, `contents`, `vw_count`) VALUES
	(3, 1, '2019-11-13', 'fffasdasf', 'asdasfff', 4);
INSERT INTO `boards` (`boards_id`, `member_id`, `created_date`, `title`, `contents`, `vw_count`) VALUES
	(4, 23, '2019-11-25', '업사이클링 제품에 대해 알고싶어요!', '업사이클링제품이 뭐죠?', 8);
INSERT INTO `boards` (`boards_id`, `member_id`, `created_date`, `title`, `contents`, `vw_count`) VALUES
	(5, 26, '2019-11-25', '날씨가 춥습니다', '오늘 하루 몸관리 잘하세요~', 1);
INSERT INTO `boards` (`boards_id`, `member_id`, `created_date`, `title`, `contents`, `vw_count`) VALUES
	(6, 26, '2019-11-25', '업사이클링 제품 구입 완료!', '예뻐요!', 3);
INSERT INTO `boards` (`boards_id`, `member_id`, `created_date`, `title`, `contents`, `vw_count`) VALUES
	(7, 31, '2019-11-25', '발표하기 좋은날!!', '은 11/27일 파이팅!', 2);
INSERT INTO `boards` (`boards_id`, `member_id`, `created_date`, `title`, `contents`, `vw_count`) VALUES
	(8, 32, '2019-11-25', '이런 제품 어떤가요?', '이 제품 만들어보려고 하는데 어떤가요?', 14);
INSERT INTO `boards` (`boards_id`, `member_id`, `created_date`, `title`, `contents`, `vw_count`) VALUES
	(9, 23, '2019-11-25', '유기농피자 먹고싶네염', 'ㅎ.....', 2);
INSERT INTO `boards` (`boards_id`, `member_id`, `created_date`, `title`, `contents`, `vw_count`) VALUES
	(10, 40, '2019-11-25', '좋은하루!', '시작!!!', 16);
INSERT INTO `boards` (`boards_id`, `member_id`, `created_date`, `title`, `contents`, `vw_count`) VALUES
	(11, 1, '2019-11-26', '안녕하세요', '운영자입니다.', 4);
/*!40000 ALTER TABLE `boards` ENABLE KEYS */;

-- 테이블 greenright.board_photos 구조 내보내기
CREATE TABLE IF NOT EXISTS `board_photos` (
  `board_photo_id` int(11) NOT NULL AUTO_INCREMENT,
  `boards_id` int(11) NOT NULL,
  `photo_path` varchar(255) NOT NULL,
  PRIMARY KEY (`board_photo_id`),
  UNIQUE KEY `UIX_board_photos` (`photo_path`),
  KEY `FK_boards_TO_board_photos` (`boards_id`),
  CONSTRAINT `FK_boards_TO_board_photos` FOREIGN KEY (`boards_id`) REFERENCES `boards` (`boards_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.board_photos:~8 rows (대략적) 내보내기
/*!40000 ALTER TABLE `board_photos` DISABLE KEYS */;
INSERT INTO `board_photos` (`board_photo_id`, `boards_id`, `photo_path`) VALUES
	(1, 1, '85b9d8e0-7d6f-40a7-adca-467387a95d4d');
INSERT INTO `board_photos` (`board_photo_id`, `boards_id`, `photo_path`) VALUES
	(2, 2, 'ad7a4ae5-e1bc-4f56-a90a-b9e5b5971c1a');
INSERT INTO `board_photos` (`board_photo_id`, `boards_id`, `photo_path`) VALUES
	(3, 3, '85307b0a-1bfc-49b0-9209-5f4f4594bc3a');
INSERT INTO `board_photos` (`board_photo_id`, `boards_id`, `photo_path`) VALUES
	(4, 6, 'c329e0cf-8822-4d88-b9ce-fd79303fbc81');
INSERT INTO `board_photos` (`board_photo_id`, `boards_id`, `photo_path`) VALUES
	(5, 8, 'd5ca295f-58ff-42d9-a76e-dc1cd88a66e5');
INSERT INTO `board_photos` (`board_photo_id`, `boards_id`, `photo_path`) VALUES
	(6, 9, '90ab3772-9a8a-4100-acaa-5b8f98bbf48a');
INSERT INTO `board_photos` (`board_photo_id`, `boards_id`, `photo_path`) VALUES
	(7, 10, '0b6284eb-e6f0-4b7b-9df4-785984f74b64');
INSERT INTO `board_photos` (`board_photo_id`, `boards_id`, `photo_path`) VALUES
	(8, 11, '2a9cd275-fdd1-4a55-ab16-550987474df8');
/*!40000 ALTER TABLE `board_photos` ENABLE KEYS */;

-- 테이블 greenright.categorys 구조 내보내기
CREATE TABLE IF NOT EXISTS `categorys` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `UIX_categorys` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.categorys:~5 rows (대략적) 내보내기
/*!40000 ALTER TABLE `categorys` DISABLE KEYS */;
INSERT INTO `categorys` (`category_id`, `category_name`) VALUES
	(4, '가구');
INSERT INTO `categorys` (`category_id`, `category_name`) VALUES
	(2, '사무');
INSERT INTO `categorys` (`category_id`, `category_name`) VALUES
	(5, '업사이클링');
INSERT INTO `categorys` (`category_id`, `category_name`) VALUES
	(3, '유기농');
INSERT INTO `categorys` (`category_id`, `category_name`) VALUES
	(1, '청소');
/*!40000 ALTER TABLE `categorys` ENABLE KEYS */;

-- 테이블 greenright.comments 구조 내보내기
CREATE TABLE IF NOT EXISTS `comments` (
  `comments_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_date` date NOT NULL,
  `contents` varchar(2000) NOT NULL,
  `member_id` int(11) NOT NULL,
  `boards_id` int(11) NOT NULL,
  PRIMARY KEY (`comments_id`),
  KEY `FK_members_TO_comments` (`member_id`),
  KEY `FK_boards_TO_comments` (`boards_id`),
  CONSTRAINT `FK_boards_TO_comments` FOREIGN KEY (`boards_id`) REFERENCES `boards` (`boards_id`),
  CONSTRAINT `FK_members_TO_comments` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.comments:~4 rows (대략적) 내보내기
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` (`comments_id`, `created_date`, `contents`, `member_id`, `boards_id`) VALUES
	(2, '2019-11-25', '1111', 21, 8);
INSERT INTO `comments` (`comments_id`, `created_date`, `contents`, `member_id`, `boards_id`) VALUES
	(4, '2019-11-26', '활기차게 시작!', 25, 10);
INSERT INTO `comments` (`comments_id`, `created_date`, `contents`, `member_id`, `boards_id`) VALUES
	(5, '2019-11-26', '고라파덕 !', 21, 10);
INSERT INTO `comments` (`comments_id`, `created_date`, `contents`, `member_id`, `boards_id`) VALUES
	(6, '2019-11-26', '좋은하루 되세요~', 39, 10);
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;

-- 테이블 greenright.deliverys 구조 내보내기
CREATE TABLE IF NOT EXISTS `deliverys` (
  `delivery_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `invoice_num` varchar(255) NOT NULL,
  `delivery_date` date NOT NULL,
  `delivery_flag` tinyint(4) DEFAULT 0,
  `courier_name` varchar(50) NOT NULL,
  `reciever_name` varchar(50) NOT NULL,
  `delivery_address` varchar(255) NOT NULL,
  `reciever_cell_phone` varchar(50) NOT NULL,
  `reciever_tel` varchar(50) DEFAULT NULL,
  `reciever_email` varchar(40) DEFAULT NULL,
  `reciever_request` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`delivery_id`),
  UNIQUE KEY `UIX_deliverys` (`invoice_num`),
  KEY `FK_orders_TO_deliverys` (`order_id`),
  CONSTRAINT `FK_orders_TO_deliverys` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.deliverys:~40 rows (대략적) 내보내기
/*!40000 ALTER TABLE `deliverys` DISABLE KEYS */;
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(1, 33, 'QzgQErNkbJPOIZ6v4i2s', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(2, 34, 'iSDyziBT6CzqmPf9l6Xq', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(3, 35, 'QJO9xRzpz21etElZpUAE', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(4, 36, 'CZJhIRyDbA8XqUIliK1C', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(5, 37, '9JL6mn2a5vUfkEpZCC10', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(6, 38, 'gbdn86ESQF6lQtFC5CTH', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(7, 39, 'P6FG60I0TJ3GOQHJVwot', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(8, 40, 'vNJoV6Sn4vobDBSmGxej', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(9, 41, '83zBwYxsGwwnGP0ldk6U', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(10, 42, 'lIog6PpbNhxwZdr81EH6', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(11, 43, 'fopziAVE7AFlxMTH6v4w', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(12, 44, 'fIgUgGgufgtZrXPcQjTI', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(13, 45, 'BD5hAyllA5NlsBPxnocR', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(14, 46, 'h3z1hkh9Sx4nV0Bs3AGQ', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(15, 47, 'qIFU7QMVmFZQe690dio9', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(16, 48, 'LcjEKhX6w92txzac69KI', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(17, 49, 'YPdPtRml6w28tmJtTutj', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(18, 50, 'ZJBjJA3Ac0XETFFtHCUD', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(19, 51, 'hTckOt2CUYzdrkll1fmL', '2019-11-22', 0, '그린라이트 택배', 'dddd', '서울 강남구 강남대로 708 (압구정동) dddd', '01031231222', NULL, 'boarddao@gmail.com', NULL);
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(20, 52, '9Wf1wH1EwvQtIBMKcWOh', '2019-11-24', 0, '그린라이트 택배', 'ADMIN', '부산 해운대구 APEC로 17 (우동) aaaa', '01011111111', NULL, 'karnenis@gmail.com', '');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(21, 53, '8pKsBcaFjqURPqC1JeY2', '2019-11-24', 0, '그린라이트 택배', 'ADMIN', '부산 해운대구 APEC로 17 (우동) aaaa', '01011111111', NULL, 'karnenis@gmail.com', 'asdfasdf');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(22, 54, 'MJ14OTv09vTClSqRgksH', '2019-11-24', 0, '그린라이트 택배', 'ADMIN', '부산 해운대구 APEC로 17 (우동) aaaa', '01011111111', NULL, 'karnenis@gmail.com', 'asdf');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(23, 55, 'NlHfeCxIsWlSQyowo3vq', '2019-11-24', 0, '그린라이트 택배', 'bbbb', '서울 강서구 마곡동로 30 (마곡동) bbbb', '01033333333', NULL, 'karnen@naver.com', 'adfasdf');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(24, 56, 'mLa3dFNPCMryY7wATup2', '2019-11-24', 0, '그린라이트 택배', 'bbbb', '서울 강서구 마곡동로 30 (마곡동) bbbb', '01033333333', NULL, 'karnen@naver.com', 'adfasdf');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(25, 57, 'zsjvkDVob8C3bYxAp4CU', '2019-11-24', 0, '그린라이트 택배', 'bbbb', '서울 강서구 마곡동로 30 (마곡동) bbbb', '01033333333', NULL, 'karnen@naver.com', 'adfasdf');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(26, 58, 'uaNfyUYoAm2epz7F0QZC', '2019-11-24', 0, '그린라이트 택배', 'bbbb', '서울 강서구 마곡동로 30 (마곡동) bbbb', '01033333333', NULL, 'karnen@naver.com', 'adfasdf');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(27, 59, '3FpNE0g5BQjFWCAct6VY', '2019-11-24', 0, '그린라이트 택배', 'bbbb', '서울 강서구 마곡동로 30 (마곡동) bbbb', '01033333333', NULL, 'karnen@naver.com', 'adfasdf');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(28, 60, 'YzoxsNdR1vy9hwmp08zh', '2019-11-24', 0, '그린라이트 택배', 'bbbb', '서울 강서구 마곡동로 30 (마곡동) bbbb', '01033333333', NULL, 'karnen@naver.com', 'adfasdf');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(29, 61, 'y3HtyBNQ2prEy8biz07w', '2019-11-24', 0, '그린라이트 택배', 'bbbb', '서울 강서구 마곡동로 30 (마곡동) bbbb', '01033333333', NULL, 'karnen@naver.com', 'adfasdf');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(30, 62, 'Hq15FvQXBnD5467Ll0dM', '2019-11-24', 0, '그린라이트 택배', 'bbbb', '서울 강서구 마곡동로 30 (마곡동) bbbb', '01033333333', NULL, 'karnen@naver.com', '');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(31, 63, 'H9qGV9bLacIRrp7hFfDk', '2019-11-25', 0, '그린라이트 택배', 'ADMIN', '부산 해운대구 APEC로 17 (우동) aaaa', '01011111111', NULL, 'karnenis@gmail.com', '제발빨리');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(32, 64, 'LbONbgWY9KKxgfBOjL90', '2019-11-25', 0, '그린라이트 택배', 'ADMIN', '부산 해운대구 APEC로 17 (우동) aaaa', '01011111111', NULL, 'karnenis@gmail.com', '제발빨리');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(33, 65, 'L0HPE7Md4Kpjn1lJjUKC', '2019-11-25', 0, '그린라이트 택배', 'user1', '경기 부천시 길주로 지하 314 (중동) 2033-4', '01033445566', NULL, 'hugebigdream@gmail.com', 'fsaddfsdfsa');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(34, 66, 'm1Q3IL9JFyyuFwPIDaaM', '2019-11-25', 0, '그린라이트 택배', 'user1', '경기 부천시 길주로 지하 314 (중동) 2033-4', '01033445566', NULL, 'hugebigdream@gmail.com', '안전하고 빠르게 부탁드립니다.');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(35, 67, 'P8kPyq7HFw8yrb4UVkDq', '2019-11-25', 0, '그린라이트 택배', 'user1', '경기 부천시 길주로 지하 314 (중동) 2033-4', '01033445566', NULL, 'hugebigdream@gmail.com', '떠벼');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(36, 68, '3QCFGcaOXJSUg9v68asj', '2019-11-25', 0, '그린라이트 택배', 'test01', '경기 성남시 분당구 판교역로 235 (삼평동) 2033-4', '01011112222', NULL, 'or2249@daum.net', '부재시 문앞에 놓아주세요.');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(37, 69, 'ZGTnwgKDCOdNZ5Gsjg6V', '2019-11-25', 0, '그린라이트 택배', 'test01', '경기 성남시 분당구 판교역로 235 (삼평동) 2033-4', '01011112222', NULL, 'or2249@daum.net', 'ㅇㅇ');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(38, 70, 'x6HiWktQjSakP8qnsERC', '2019-11-26', 0, '그린라이트 택배', 'bbbb', '서울 강서구 마곡동로 30 (마곡동) bbbb', '01033333333', NULL, 'karnen@naver.com', '');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(39, 71, 'Mtjw8bcpPiZZw1zxBUmL', '2019-11-26', 0, '그린라이트 택배', 'greenright', '경기 성남시 분당구 판교역로 235 (삼평동) N231', '01051975564', NULL, 'dydcks5@naver.com', 'q');
INSERT INTO `deliverys` (`delivery_id`, `order_id`, `invoice_num`, `delivery_date`, `delivery_flag`, `courier_name`, `reciever_name`, `delivery_address`, `reciever_cell_phone`, `reciever_tel`, `reciever_email`, `reciever_request`) VALUES
	(40, 72, 'TnEUcy06qok5YhnXqbGu', '2019-11-26', 0, '그린라이트 택배', 'green', '경기 성남시 분당구 판교역로 235 (삼평동) N2021', '01051975546', NULL, 'dydcks5@naver.com', '부재시 문앞에 놓아주세요.');
/*!40000 ALTER TABLE `deliverys` ENABLE KEYS */;

-- 테이블 greenright.exhibitions 구조 내보내기
CREATE TABLE IF NOT EXISTS `exhibitions` (
  `member_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `photo_path` varchar(255) NOT NULL,
  `main_photo_path` varchar(255) NOT NULL,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `UIX_exhibitions` (`name`),
  CONSTRAINT `FK_sellers_TO_exhibitions` FOREIGN KEY (`member_id`) REFERENCES `sellers` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.exhibitions:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `exhibitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `exhibitions` ENABLE KEYS */;

-- 테이블 greenright.faqs 구조 내보내기
CREATE TABLE IF NOT EXISTS `faqs` (
  `faq_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `question_type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `contents` varchar(2000) NOT NULL,
  PRIMARY KEY (`faq_id`),
  KEY `FK_faqs_members` (`member_id`),
  CONSTRAINT `FK_faqs_members` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.faqs:~24 rows (대략적) 내보내기
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(1, 1, '배송안내', '배송지를 두 곳으로 할 수 있나요?', '여러 배송지로 배송해야 할 경우 각각 개별 주문을 해야합니다. ');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(2, 1, '배송안내', '배송중일 때 상품취소는 어떻게 하나요?', '상품이 택배사로 인계되어 배송중인 경우 취소 신청이 불가합니다.\r\n 이 경우 상품 수령후 반품으로 진행해야 합니다.');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(3, 1, '배송안내', '이미 주문했는데 배송지 변경 가능한가요?', '배송지 변경의 경우 상품 출고전 상태에서만 고객센터를 통해 변경이 가능합니다. \r\n부득이하게 배송지 변경이 필요하신 경우 고객센터를 통해 변경 가능 여부 확인해 주시기 바랍니다.');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(4, 1, '배송안내', '주문한 상품을 해외로 배송할 수 있나요?', '해외 배송은 불가 합니다.');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(5, 1, '배송안내', '배송완료인데 아직 못 받았아요.', '택배사 또는 해당지역의 택배 기사님 사정에 의해 실제 물품 전달일이 1~2일 지연 될 수 있습니다.\r\n주문 시 작성하신 수령 정보 및 배송 메시지를 확인하기 바랍니다.\r\n이후에도 수령하지 못하셨다면 고객센터를 통하여 연락 부탁 드립니다.');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(6, 1, '주문', '상품 주문시 회원가입을 꼭 해야 하나요?', '상품 주문을 위해서는 회원가입이 반드시 필요합니다.');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(7, 1, '주문', '주문 후 결제 방법 변경 및 할부 변경하고 싶어요.', '결제 완료된 주문에 대한 결제수단 변경은 불가하며, 결제 완료 이후 할부 변경 역시 불가 합니다.\r\n결제 수단 변경 및 할부 변경을 원하시는 경우, 기존 주문을 취소하신 후 재주문 하셔야 합니다.\r\n');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(8, 1, '주문', '주문상품을 다른걸로 바꾸고 싶어요.', '주문을 완료한 상품의 옵션 변경이 불가합니다.\r\n주문 취소 후, 원하는 옵션으로 재구매 하셔야 합니다.\r\n주문이 이미 상품 준비중 단계로 넘어가 취소가 불가한 경우에는, \r\n반품 접수를 통해 새로운 상품으로 구매 해주셔야 합니다.');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(9, 1, '주문', '주문한 상품을 결제하는 방법은 어떤 것이 있나요?', '신용카드, 실시간 계좌이체, 삼성페이, 무통장입금, 휴대폰 소액결제 중 선택하시어 결제 하시면 됩니다.\r\n');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(10, 1, '주문', '무통장입금 결제 후 주문금액을 입금했는데, 주문이  취소되었습니다', '입금하신 금액은 등록된 환불계좌로 영업일 1일내 환불됩니다.\r\n환불계좌는 본인예금주의 계좌만 등록 가능합니다.');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(11, 1, '주문', '주문한 적이 없는 상품을 수령하였는데 누가 주문한 상품인지 알고 싶어요', '상품이 배송 되기전에, 주문자 고객님께서 신청해주신 수취인 고객님의 연락처로 주문자의 정보 및 운송장 번호와 배송예정일이 문자로 발송 됩니다. ');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(12, 1, '주문', '주문한 상품의 배송 상태가 계속 \'상품준비중\'으로 확인됩니다.', '상품준비중은 판매자가 주문을 확인하고, 상품을 준비하는 상태입니다.\r\n주문량이 많거나 판매자 사정으로 준비가 늦어지는 경우 \'상품 준비중 \' 단계가 길어질 수 있습니다.\r\n');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(13, 1, '주문', '무통장 입금을 선택하여 주문하였습니다. 언제까지 입금해야 하나요?', '결제수단 중 무통장 입금을 선택하셔서 주문하신 경우 주문일로부터 1일 이내에 입금 하셔야 합니다.\r\n\r\n[가상계좌 입금 시 유의사항]\r\n① 가상계좌는 하나의 주문번호에 하나의 계좌번호가 생성되기 때문에 여러 가지 상품을 각각 주문하셨으면 \r\n    입금도 해당 주문 별로 각각 하셔야 하며, 여러 가지 상품을 장바구니에 담아 한 번에 주문하셨으면 \r\n    주문 총 금액을 한 번에 입금해 주시면 됩니다.\r\n② 무통장입금 기간은 주문일로부터 7일 이내에 입금해 주셔야 하며, 기간 안에 입금확인이 되지 않으면 \r\n    주문은 자동 취소됩니다. \r\n③ 또한, 주문이 취소되면 해당 주문으로 생성된 가상계좌 번호도 소멸됩니다.\r\n④ 입금 시에는 입금예정자, 은행, 금액, 가상계좌 번호가 일치해야 입금 후 바로 확인이 가능하며, \r\n    입금예정 정보와 다르면 주문과 입금이 연결되지 않으니 유의해 주시기 바랍니다.');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(14, 1, '주문', '이미 결제한 주문건의 결제 수단을 변경 할 수 있나요?', '결제수단 변경은 무통장 입금에서 신용카드 결제로만 변경 가능합니다.\r\n단 무통장 입금 주문건이 결제 완료 상태에는 변경이 불가능하면 입금 전에만 변경 가능합니다.');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(15, 1, '교환,환불', '상품을 교환하고 싶어요! 어떻게 하면 되나요?', '′전자상거래 등에서의 소비자보호에 관한 법률′에 의거하여 교환 기간 이내에는 판매업체에 교환을\r\n요청하 실 수 있습니다.\r\n\r\n[교환가능 기간]\r\n구매자 단순변심 : 물품 수령 후 7일 이내\r\n표시, 광고 상이, 물품하자 : 물품 수령 후 3개월 이내, 또는 사실을 알게 된 날로부터 30일 이내\r\n\r\n');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(16, 1, '교환,환불', '교환이 가능한 경우와 가능하지 않은 경우에 대해 자세히 알고 싶습니다.', '′전자상거래 등에서의 소비자보호에 관한 법률′에 의거하여 교환 기간 이내에는 판매업체로\r\n교환을 요청하실 수 있습니다.\r\n\r\n[교환이 가능한 경우]\r\n구매자 단순변심 : 물품 수령 후 7일 이내\r\n표시, 광고 상이, 물품하자 : 물품 수령 후 3개월 이내, 또는 사실을 알게 된 날로부터 30일 이내\r\n\r\n[교환이 불가능한 경우]\r\n① 교환가능 기간이 경과된 경우(상단 내용 참고)\r\n② 고객님의 과실로 상품 등이 멸실 또는 훼손된 경우\r\n   (단, 상품 내용을 확인하기 위하여 포장 등을 훼손한 경우는 제외) \r\n③ 포장을 개봉하였거나 포장이 훼손되어 상품가치가 현저히 상실된 경우 \r\n④ 고객님의 사용 또는 일부 소비에 의하여 상품의 가치가 현저히 감소한 경우 \r\n⑤ 시간의 경과에 의하여 재판매가 곤란할 정도로 상품의 가치가 현저히 감소한 경우\r\n⑥ 고객주문 확인 후 상품제작에 들어가는 주문 제작 상품\r\n⑦ 복제가 가능한 상품 등의 포장을 훼손한 경우  ');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(17, 1, '교환,환불', '교환을 신청하면 언제쯤 새 상품을 받아볼 수 있나요?', '교환은 판매업체와 상품에 따라 기간에 차이가 있을 수 있으며, 수령하신 상품이 먼저 회수되어\r\n판매업체에 도착하면 새 상품이 발송됩니다.\r\n\r\n[교환 처리 기간]\r\n① 교환이 접수되면 택배사에서 고객님이 수령하신 상품을 회수합니다.\r\n② 회수된 상품이 판매업체에 도착하면 교환사유와 상품 상태를 확인합니다.\r\n③ 상품 확인 후 새 상품을 업체에서 발송합니다.\r\n\r\n위 단계를 거친 후 고객님께서는 교환 상품을 받아보실 수 있으며, 그 기간은 보통 1주일 정도 \r\n소요됩니다.');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(18, 1, '교환,환불', '교환을 할 경우 상품을 보내고 다시 받는 택배 비용은 누가 부담하나요?', '교환비용은 교환사유에 따라 비용부담이 결정됩니다.\r\n\r\n[GreenRight/판매업체가 교환비용을 부담하는 경우]\r\n상품 하자(불량/파손) 또는 판매업체의 실수로 오배송된 상품의 왕복 택배비는 판매업체 부담\r\n하며, 교환 전에 판매업체와 연락하여 교환비용에 대해 명확히 하셔야 합니다.\r\n\r\n[구매자가 교환비용을 부담하는 경우]\r\n옵션 변경 등의 사유로 교환하실 때는 구매자 변심에 의한 교환으로 왕복 택배비를\r\n구매자인 고객님께서 부담하셔야 합니다.\r\n\r\n\r\n');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(19, 1, '교환,환불', '취소/환불 했는데 신용카드 청구서에 금액이 청구 되었어요.', '신용카드는 취소/반품 시 해당 카드사로 결제 취소를 요청하여 고객님께 카드 대금이 청구되지 \r\n않도록 하고 있습니다.\r\n\r\n[취소/반품 완료 후 청구서에 결제금액이 청구되었을 때]\r\n① 신용카드는 고객님의 결제일에 따라 청구서 작성시기가 달라, GreenRight에서 카드사로 취소를\r\n   요청 하더라도 청구되는 경우가 있습니다.\r\n② 취소 시점에 따라 혹시라도 대금이 먼저 결제된 경우에는 익월 카드사에서 자동으로 고객님 \r\n   계좌로 입금 또는 기존 청구금액에서 삭감되어 청구하게 됩니다.\r\n③ 신용카드 승인/매입 취소 기간은 카드사별로 차이가 있으나, 약 5 ~ 7일(공휴일 제외) 정도가 \r\n   소요되며, 취소 확인 문의와 자세한 환불방법, 환불일자에 대한 자세한 내용은 해당 카드사로 \r\n   직접 문의하여 주시기 바랍니다.\r\n');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(20, 1, '교환,환불', '환불받을 때, 총 환불액에서 고객이 부담하는 배송비를 제하고 받을 수 있나요?', '반품 확정 후 결제 수단에 따라 반품 배송비는 자동 차감 됩니다.\r\n\r\n< 반품 완료 후 결제 수단별 반품 배송비 결제 >\r\n  ⓐ 실시간 계좌이체 : 환불 금액에서 반품 배송비 차감 후 환불\r\n  ⓑ 무통장입금 : 환불 금액에서 반품 배송비 차감 후 환불\r\n  ⓒ 신용카드 : 반품 배송비 자동 재결제 \r\n  ⓓ 휴대폰 결제 : 반품 배송비 수동 재결제');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(21, 1, '교환,환불', '반품 완료 후 환불은 언제 입금 되나요?', '반품 배송비 결제가 완료되면 자동으로 환불처리가 진행 됩니다.\r\n※ 반품 배송비는 후불 결제를 통해 전산처리되며, 선불지급하거나 동봉하는 경우 환불이 지연될 수 있습니다.\r\n\r\n< 반품 완료 후 결제 수단에 따른 환불 일정 >\r\n  ⓐ 실시간 계좌이체 : 영업일 기준 3일 이내에 환불.\r\n  ⓑ 무통장입금 : 영업 일기준 3일 이내 환불.\r\n  ⓒ 신용카드 :  최장 7일 내  해당 카드사에 기존 승인내역에 대한 취소 확인  가능.\r\n                         (승인취소 및 결제 반영일에 따라 입금날짜는 카드사 별로 다를 수 있으니 \r\n                          자세한 내용은 해당 카드사로 문의하여 주십시오.)');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(22, 1, '기타', '전시회 랭킹은 믿을 수 있나요?', '전시회 페이지의 작품은 추천수를 기반으로 자동으로 계산되며, GreenRight 측에서 어떠한 조작도 행하고 있지 않습니다.');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(23, 1, '기타', '비밀번호를 분실했는데, 이메일이나 문자메세지로 임시 비밀번호가 도착하지 않아요.', '스팸차단여부 우선 확인 필요 \r\n\r\n이메일 및 휴대폰에서 일부 이메일 계정이나 휴대폰 문자서비스가 스팸으로 자동 분리될 수 있으며,\r\n통신사 부가서비스로 특정번호 또는 특정문구 차단서비스가 가입되어 있는 경우 수신이 어려울 수 있습니다.\r\n번거로우시겠지만 수신하는 메일 계정의 스팸메일함 또는 스팸문자메세지함을 확인 부탁드리며\r\n위 2가지 내용 확인 후에도 수신이 되지 않을 시 고객센터를 통해 문의 접수 부탁드립니다.');
INSERT INTO `faqs` (`faq_id`, `member_id`, `question_type`, `title`, `contents`) VALUES
	(25, 30, '기타', '쿠폰 사용 안내', '쿠폰 중복 사용은 안됩니다.');
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;

-- 테이블 greenright.groups 구조 내보내기
CREATE TABLE IF NOT EXISTS `groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `group_name` varchar(255) NOT NULL,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `UIX_groups` (`group_name`),
  KEY `FK_categorys_TO_groups` (`category_id`),
  CONSTRAINT `FK_categorys_TO_groups` FOREIGN KEY (`category_id`) REFERENCES `categorys` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.groups:~17 rows (대략적) 내보내기
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(1, 1, '세제류');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(2, 1, '위생용품');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(3, 1, '화장지');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(4, 1, '티슈');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(5, 2, '복사용지');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(6, 2, '화일');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(7, 2, '토너');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(8, 2, '기타');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(9, 3, '과일');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(10, 3, '채소');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(11, 3, '간식');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(12, 3, '축산품');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(13, 4, '침대');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(14, 4, '소파');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(15, 4, '테이블');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(16, 4, '의자');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(17, 4, '파티션');
INSERT INTO `groups` (`group_id`, `category_id`, `group_name`) VALUES
	(18, 5, '업사이클링');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;

-- 테이블 greenright.likes 구조 내보내기
CREATE TABLE IF NOT EXISTS `likes` (
  `member_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`member_id`,`product_id`),
  KEY `FK_products_TO_likes` (`product_id`),
  CONSTRAINT `FK_members_TO_likes` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_products_TO_likes` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.likes:~69 rows (대략적) 내보내기
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(10, 51);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(21, 12);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 5);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 6);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 7);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 9);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 11);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 12);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 13);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 14);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 15);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 16);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 17);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 18);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 19);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 20);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 21);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 22);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 23);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 24);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 25);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 26);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 27);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 28);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 29);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 30);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 31);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 32);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 33);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 34);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 36);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 37);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 38);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 39);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 40);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 41);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(23, 42);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(27, 5);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(27, 9);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(30, 43);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(30, 44);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(31, 9);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(33, 33);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(34, 12);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(34, 36);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(38, 9);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(38, 11);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(38, 12);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(38, 19);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(40, 6);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(40, 7);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(40, 12);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(40, 19);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(40, 28);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(40, 40);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(40, 43);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(40, 44);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(44, 11);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(44, 12);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(44, 15);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(44, 17);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(44, 19);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(44, 44);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(46, 9);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(46, 26);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(46, 36);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(46, 39);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(46, 44);
INSERT INTO `likes` (`member_id`, `product_id`) VALUES
	(46, 46);
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;

-- 테이블 greenright.members 구조 내보내기
CREATE TABLE IF NOT EXISTS `members` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_class` int(11) NOT NULL DEFAULT 1,
  `registered_date` date NOT NULL,
  `id` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `certification_flag` tinyint(1) NOT NULL DEFAULT 0,
  `cell_phone` varchar(50) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(40) NOT NULL,
  `postal_code` varchar(10) NOT NULL,
  `default_address` varchar(255) NOT NULL,
  `detail_address` varchar(255) NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL,
  `authkey` varchar(255) DEFAULT NULL,
  `password_authkey` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `UIX_members` (`id`),
  UNIQUE KEY `UIX_members2` (`cell_phone`),
  UNIQUE KEY `UIX_members3` (`email`),
  UNIQUE KEY `UIX_members4` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.members:~25 rows (대략적) 내보내기
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(1, 0, '2019-11-11', 'aaaa', '*D54C8CF5290EDFF3AE9923A0C1F5EA80097221B3', 1, '01011111111', 'ADMIN', 'karnenis@gmail.com', '48060', '부산 해운대구 APEC로 17 (우동)', 'aaaa', '졸업한 초등학교?', 'aaaa', 'COMPLETE', 'COMPLETE');
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(10, 2, '2019-11-15', 'bbbb', '*367BE0AF56D3C7A0A3C1725AFBC9D25E1E95C36E', 1, '01033333333', 'gggg', 'karnen@naver.com', '07805', '서울 강서구 마곡동로 30 (마곡동)', 'bbbb', '좋아하는 책?', 'bbbb', 'COMPLETE', '5f4bAV82GnYG5vbuUFjxztfXTa3kKg07kf9N6XQw');
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(13, 1, '2019-11-16', 'cccc', '*7FD8731E0E2AF5F5534B481F2A252CDDF9B08D5B', 1, '01031231231', 'cccc', 'lessondao@gmail.com', '48060', '부산 해운대구 APEC로 17 (우동)', 'cccc', '좋아하는 책?', 'cccc', 'COMPLETE', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(19, 2, '2019-11-16', 'dddd', '*E4FF4DC7DB17CD93463907BE4C1A0F3362A7CAF6', 0, '01031231222', 'dddd', 'boarddao@gmail.com', '06000', '서울 강남구 강남대로 708 (압구정동)', 'dddd', '좋아하는 책?', 'dddd', 'oMrW4TKW1FW5oRL4FPe4tfP3uFiOB5FIY5nokehs', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(21, 0, '2019-11-25', 'leeyc21', '*89C6B530AA78695E257E55D63C00A6EC9AD3E977', 0, '01021345167', 'leeyc21', 'dydcks4@gmail.com', '13525', '경기 성남시 분당구 동판교로 153 (삼평동, 봇들마을8단지아파트)', '801-101', '좋아하는 책?', '풀하우스', 'buRZVVYONrSwm86ym4LHgZ6caqdL1sCrG6g60JjW', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(23, 2, '2019-11-25', 'user1', '*89C6B530AA78695E257E55D63C00A6EC9AD3E977', 1, '01033445566', 'user1', 'hugebigdream@gmail.com', '14549', '경기 부천시 길주로 지하 314 (중동)', '2033-4', '좋아하는 책?', '마나책', 'COMPLETE', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(25, 2, '2019-11-25', 'js0516', '*89C6B530AA78695E257E55D63C00A6EC9AD3E977', 0, '01024235570', 'js0516', 'classy960516@gmail.com', '13617', '경기 성남시 분당구 미금로 216 (금곡동, 청솔마을주공9단지아파트)', '905-1403', '좋아하는 책?', '파피용', 'Ze3o3McIY8NOLdnFSKVhA2Jo3YrHUynRCpn4FzFW', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(26, 1, '2019-11-25', 'greensu', '*FE10AAC96C32E439EE3596492BB4B3308290EE50', 1, '01029992999', 'greensumer', 'greeeenright@gmail.com', '06120', '서울 강남구 봉은사로 지하 102 (역삼동)', '백암빌딩 203호', '좋아하는 책?', '삼국지', 'COMPLETE', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(27, 2, '2019-11-25', 'jr0608', '*89C6B530AA78695E257E55D63C00A6EC9AD3E977', 0, '01089657543', 'jr0608', 'jr0608@gmail.com', '12254', '경기 남양주시 미금로 10 (다산동)', '8504', '졸업한 초등학교?', '청솔초등학교', 'zZGsAmpF7blU6JiB3UvCYAjdQAgCmfGtpPDtwXrN', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(28, 2, '2019-11-25', 'greenbe', '*FE10AAC96C32E439EE3596492BB4B3308290EE50', 1, '01015441544', 'greenbe', 'greenrightseller@gmail.com', '06303', '서울 강남구 개포로 207 (개포동)', '백암빌딩 203호', '좋아하는 책?', '자바의정석', 'COMPLETE', 'l82lrIRol6rf0LsT4aqq4MZgWWMp3hmdLGD6ToVq');
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(30, 0, '2019-11-25', 'admin01', '*348B2E74CDAC5EEF8E3548D4AE4A967DB79A00F4', 0, '01021315467', 'admin01', 'greenadmin@greenright.com', '13494', '경기 성남시 분당구 판교역로 235 (삼평동)', 'S동 101호', '태어난 곳?', '분당', 'TSm6d3IvdFqR6ucY6Gqgo1qsmCKlybiaP9LxUNsG', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(31, 2, '2019-11-25', 'chldntjr', '*EBE95EE28E1231BDEDD5F23FE7AEB258C8CDC01D', 0, '01051317784', 'chldntjr', 'chldntjr@naver.com', '13494', '경기 성남시 분당구 판교역로 235 (삼평동)', '507-844', '졸업한 초등학교?', '유진', 'u11QA0UK2e6pudtQWFd2sYxLj19G751DVrVqA4AX', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(32, 1, '2019-11-25', 'ren1103', '*89C6B530AA78695E257E55D63C00A6EC9AD3E977', 0, '01011031568', 'ren1103', 'ren1103@gmail.com', '13626', '경기 성남시 분당구 구미동 212-1', '502-1405', '어머니 이름?', '김명순', 'Ek6zbxr8f1N9jHKyoGMLa5NXLkRHstVmxy7TNiHH', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(33, 2, '2019-11-25', 'rladbswo', '*348B2E74CDAC5EEF8E3548D4AE4A967DB79A00F4', 0, '01055139943', '그린라잇!!!', 'dbswo@gmail.com', '13494', '경기 성남시 분당구 판교역로 235 (삼평동)', 'N동 201호', '태어난 곳?', '부산', 'FpgZp4LuXsCBKOPLBHlbbw4pUuPc0ZNcEFzyHKU3', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(34, 2, '2019-11-25', 'chillin', '*FE10AAC96C32E439EE3596492BB4B3308290EE50', 1, '01078454578', 'chillin', 'greeenright@gmail.com', '24062', '강원 철원군 서면 금강로 7819', '와수베가스', '존경하는 사람?', '현대빈', 'COMPLETE', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(35, 2, '2019-11-25', 'aron11', '*89C6B530AA78695E257E55D63C00A6EC9AD3E977', 0, '01057891540', 'aron11', 'aron@gmail.com', '13487', '경기 성남시 분당구 대왕판교로 579 (삼평동)', '102-1403', '태어난 곳?', '경기도', '0Ui1fBJe85qshxNgq3uJAExH3qzkSKt168uSJano', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(36, 2, '2019-11-25', 'dong11', '*89C6B530AA78695E257E55D63C00A6EC9AD3E977', 0, '01025684972', 'dong11', 'dogn@gmail.com', '06267', '서울 강남구 강남대로 238 (도곡동)', '1004-102', '존경하는 사람?', '어머니', 'dCVk5HbwmjXhoNW6C2EGvHQ8DP8pMoSTQUg0gQB6', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(37, 2, '2019-11-25', 'hj1209', '*89C6B530AA78695E257E55D63C00A6EC9AD3E977', 0, '01025681547', 'hj1209', 'hj@gmail.com', '06350', '서울 강남구 광평로 61 (일원동)', '102-106', '존경하는 사람?', '아버지', '6fxx4xyWWLvMnjvEylERLTINgxCxD6KsMJKPKA9Q', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(38, 2, '2019-11-25', 'dlgywls', '*348B2E74CDAC5EEF8E3548D4AE4A967DB79A00F4', 0, '01055483345', 'dlgywls', 'gywls21@gmail.com', '13494', '경기 성남시 분당구 판교역로 235 (삼평동)', 'N1326', '존경하는 사람?', '아브라함링컨', 'XTDXgCwpLciDMIoOYYzuJN1XMD9aTiFoIBT06gwC', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(39, 2, '2019-11-25', 'banana', '*FE10AAC96C32E439EE3596492BB4B3308290EE50', 1, '01049357502', 'banana', 'reenrightmember@gmail.com', '11000', '경기 연천군 신서면 강변길 145', '대광빌라 101호', '태어난 곳?', '우주', 'COMPLETE', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(40, 1, '2019-11-25', 'test01', '*556A1819C902459389465119AFDEF298638C520B', 0, '01011112222', 'test01', 'or2249@daum.net', '13494', '경기 성남시 분당구 판교역로 235 (삼평동)', '2033-4', '졸업한 초등학교?', 'aa', 'Rm4pdxAt5H4z4z7ebBIRPqcEslVwGqQPYTlctQbB', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(41, 1, '2019-11-25', 'asdf', '*7F0C90A004C46C64A0EB9DDDCE5DE0DC437A635C', 0, '01011231321', 'asdf', 'asdf@adsf.asdf', '48060', '부산 해운대구 APEC로 17 (우동)', 'asdf', '좋아하는 책?', 'asdf', 'jhM1LXllEZ3o5AN2IQqOqOotxO43DBl3w0GvT17V', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(42, 1, '2019-11-25', 'ffff', '*415B1EE9AB27AFCDFEC800787C675C85E606D11D', 0, '01033333312', 'ffff', 'ffff@ffff.ffff', '46760', '부산 강서구 르노삼성대로 14 (신호동)', 'aaaa', '좋아하는 책?', 'ffff', 'GBtKgt1cTzPNJ5519XKzBvBQmRb1gUsn3MAg4knx', NULL);
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(44, 1, '2019-11-26', 'greenright', '*348B2E74CDAC5EEF8E3548D4AE4A967DB79A00F4', 1, '01051975564', 'greenright', 'dydcks2@naver.com', '13494', '경기 성남시 분당구 판교역로 235 (삼평동)', 'N231', '좋아하는 책?', '풀하우스', 'COMPLETE', 'COMPLETE');
INSERT INTO `members` (`member_id`, `member_class`, `registered_date`, `id`, `password`, `certification_flag`, `cell_phone`, `name`, `email`, `postal_code`, `default_address`, `detail_address`, `question`, `answer`, `authkey`, `password_authkey`) VALUES
	(46, 1, '2019-11-26', 'green', '*EBE95EE28E1231BDEDD5F23FE7AEB258C8CDC01D', 1, '01051975546', 'green', 'dydcks5@naver.com', '13494', '경기 성남시 분당구 판교역로 235 (삼평동)', 'N2021', '좋아하는 책?', '풀하우스', 'COMPLETE', 'COMPLETE');
/*!40000 ALTER TABLE `members` ENABLE KEYS */;

-- 테이블 greenright.mileages 구조 내보내기
CREATE TABLE IF NOT EXISTS `mileages` (
  `member_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `used_flag` tinyint(1) NOT NULL,
  `used_date` date NOT NULL,
  `mileage_point` int(11) NOT NULL,
  PRIMARY KEY (`member_id`,`order_id`,`used_flag`),
  KEY `FK_orders_TO_mileages` (`order_id`),
  CONSTRAINT `FK_members_TO_mileages` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`),
  CONSTRAINT `FK_orders_TO_mileages` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.mileages:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `mileages` DISABLE KEYS */;
/*!40000 ALTER TABLE `mileages` ENABLE KEYS */;

-- 테이블 greenright.options 구조 내보내기
CREATE TABLE IF NOT EXISTS `options` (
  `options_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `options_name` varchar(255) NOT NULL,
  PRIMARY KEY (`options_id`),
  KEY `FK_products_TO_options` (`product_id`),
  CONSTRAINT `FK_products_TO_options` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.options:~44 rows (대략적) 내보내기
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(4, 5, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(5, 6, '용량');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(6, 7, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(8, 9, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(10, 11, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(11, 12, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(12, 13, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(14, 15, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(15, 16, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(16, 17, '추가 택배비');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(17, 18, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(18, 19, '색상');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(19, 20, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(20, 21, '제주 산간지역 추가택배비');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(21, 22, '제주 산간지역 추가 택배비');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(22, 23, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(23, 24, '제주 산가 지역 추가 택배비');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(24, 25, '색깔');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(25, 26, '제주 산간 지역 추가 택배비');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(26, 27, '소파종류');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(27, 28, '제주 산간 지역 추가 택배비');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(28, 29, '제주 산간 지역 추가 택배비');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(29, 30, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(30, 31, '제주산간 지역 추가 택배비');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(31, 32, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(32, 33, '사이드체어');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(33, 34, '크기');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(35, 36, '쿠션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(36, 37, '제주 산간 지역 추가 택배비');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(37, 38, '옵션을 선택해 주세요');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(38, 39, '색깔');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(39, 40, '옵션을 선택해 주세요');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(40, 41, '목재종류');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(41, 42, '옵션을 선택해주세요');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(42, 43, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(43, 44, '색깔');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(44, 45, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(45, 46, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(46, 47, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(47, 48, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(49, 50, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(50, 51, '필수 옵션입니다');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(51, 53, '기본옵션');
INSERT INTO `options` (`options_id`, `product_id`, `options_name`) VALUES
	(53, 55, '기본옵션');
/*!40000 ALTER TABLE `options` ENABLE KEYS */;

-- 테이블 greenright.option_items 구조 내보내기
CREATE TABLE IF NOT EXISTS `option_items` (
  `option_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `options_id` int(11) NOT NULL,
  `option_item_matters` varchar(255) NOT NULL,
  `options_price` int(11) unsigned NOT NULL DEFAULT 0,
  `options_quantity` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`option_item_id`),
  KEY `FK_options_TO_option_items` (`options_id`),
  CONSTRAINT `FK_options_TO_option_items` FOREIGN KEY (`options_id`) REFERENCES `options` (`options_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.option_items:~59 rows (대략적) 내보내기
/*!40000 ALTER TABLE `option_items` DISABLE KEYS */;
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(7, 4, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(8, 5, '500g', 0, 50);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(9, 5, '1kg', 10000, 50);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(10, 6, '기본옵션입니다', 0, 200);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(12, 8, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(14, 10, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(15, 11, '기본옵션입니다', 0, 100);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(16, 12, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(18, 14, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(19, 15, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(20, 16, '제주 산간', 2500, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(21, 17, '기본옵션입니다', 0, 100);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(22, 18, '패브릭 커피 브라운', 0, 50);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(23, 18, '패브릭 아이보리', 0, 50);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(24, 19, '기본옵션입니다', 0, 100);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(25, 20, '제주 산간', 2500, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(26, 21, '제주 산간', 2500, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(27, 22, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(28, 23, '제주 산간', 2500, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(29, 24, '자주javascript:void(0)', 5000, 20);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(30, 24, '흰색', 5000, 20);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(31, 24, '검정', 5000, 10);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(32, 25, '제주 산간', 2500, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(33, 26, '4인가죽소파-흰색', 0, 20);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(34, 26, '2인 펄 체어 - 흰색', 0, 30);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(35, 27, '제주 산간', 2500, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(36, 28, '제주 산간', 2500, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(37, 29, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(38, 30, '제주 산간', 2500, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(39, 31, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(40, 32, 'left 체어', 100000, 50);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(41, 32, 'right 체어', 100000, 50);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(42, 33, '국화차(소)8g', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(43, 33, '국화차(대)12g', 1000, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(45, 35, '쿠션A', 50000, 40);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(46, 35, '쿠션B', 60000, 30);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(47, 35, '쿠션C', 50000, 30);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(48, 36, '제주 산간', 2500, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(49, 37, '베이직 1개 - 7팩', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(50, 38, '녹색', 0, 30);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(51, 38, '갈색', 0, 30);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(52, 38, '검정', 0, 40);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(53, 39, '오리지널', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(54, 39, '현미', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(55, 40, '월넛', 0, 50);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(56, 40, '메이플', 0, 50);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(57, 41, '유기농 사과떡튀밥', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(58, 42, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(59, 43, '흰색', 0, 30);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(60, 43, '분홍', 0, 30);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(61, 43, '파랑', 0, 30);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(62, 44, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(63, 45, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(64, 46, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(65, 47, '기본옵션입니다', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(68, 49, '기본옵션!', 5000, 100);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(69, 50, '퀸사이즈', 0, 1);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(70, 51, '기본옵션입니다', 0, 50);
INSERT INTO `option_items` (`option_item_id`, `options_id`, `option_item_matters`, `options_price`, `options_quantity`) VALUES
	(73, 53, '기본옵션입니다', 0, 1);
/*!40000 ALTER TABLE `option_items` ENABLE KEYS */;

-- 테이블 greenright.orders 구조 내보내기
CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_flag` tinyint(1) NOT NULL,
  `payment_way` varchar(255) NOT NULL,
  `payment_price` int(11) NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `FK_members_TO_orders` (`member_id`),
  CONSTRAINT `FK_members_TO_orders` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.orders:~43 rows (대략적) 내보내기
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(1, 19, '2019-11-21', 0, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(2, 19, '2019-11-21', 0, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(3, 19, '2019-11-21', 1, 'trans', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(33, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(34, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(35, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(36, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(37, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(38, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(39, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(40, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(41, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(42, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(43, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(44, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(45, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(46, 19, '2019-11-22', 1, 'samsung', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(47, 19, '2019-11-22', 1, 'trans', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(48, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(49, 19, '2019-11-22', 1, 'phone', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(50, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(51, 19, '2019-11-22', 1, 'card', 0);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(52, 1, '2019-11-24', 1, '카드', 2501);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(53, 1, '2019-11-24', 1, '카드', 2501);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(54, 1, '2019-11-24', 1, '카드', 2025001);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(55, 10, '2019-11-24', 1, '카드', 35002);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(56, 10, '2019-11-24', 0, '카드', 35002);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(57, 10, '2019-11-24', 1, '카드', 35002);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(58, 10, '2019-11-24', 1, '카드', 35002);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(59, 10, '2019-11-24', 1, '휴대폰 소액결제', 35002);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(60, 10, '2019-11-24', 1, '카드', 35002);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(61, 10, '2019-11-24', 1, '휴대폰 소액결제', 35002);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(62, 10, '2019-11-24', 1, '실시간 계좌이체', 35002);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(63, 1, '2019-11-25', 1, '카드', 4530004);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(64, 1, '2019-11-25', 1, '카드', 4530004);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(65, 23, '2019-11-25', 1, '카드', 174100);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(66, 23, '2019-11-25', 1, '카드', 256600);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(67, 23, '2019-11-25', 1, '카드', 256600);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(68, 40, '2019-11-25', 1, '카드', 2062600);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(69, 40, '2019-11-25', 1, '카드', 2062600);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(70, 10, '2019-11-26', 1, '카드', 45000);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(71, 44, '2019-11-26', 1, '카드', 606000);
INSERT INTO `orders` (`order_id`, `member_id`, `payment_date`, `payment_flag`, `payment_way`, `payment_price`) VALUES
	(72, 46, '2019-11-26', 1, '카드', 764000);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

-- 테이블 greenright.order_products 구조 내보내기
CREATE TABLE IF NOT EXISTS `order_products` (
  `order_id` int(11) NOT NULL,
  `option_item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`order_id`,`option_item_id`),
  KEY `FK_option_items_TO_order_products` (`option_item_id`),
  CONSTRAINT `FK_option_items_TO_order_products` FOREIGN KEY (`option_item_id`) REFERENCES `option_items` (`option_item_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_orders_TO_order_products` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.order_products:~14 rows (대략적) 내보내기
/*!40000 ALTER TABLE `order_products` DISABLE KEYS */;
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(65, 7, 4, 42900);
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(66, 7, 4, 42900);
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(66, 8, 4, 20000);
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(67, 7, 4, 42900);
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(67, 8, 4, 20000);
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(68, 15, 4, 214900);
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(68, 23, 2, 599000);
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(69, 15, 4, 214900);
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(69, 23, 2, 599000);
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(70, 65, 2, 21250);
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(71, 15, 2, 1000);
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(71, 23, 1, 599000);
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(72, 15, 2, 80000);
INSERT INTO `order_products` (`order_id`, `option_item_id`, `quantity`, `price`) VALUES
	(72, 23, 1, 599000);
/*!40000 ALTER TABLE `order_products` ENABLE KEYS */;

-- 테이블 greenright.private_answers 구조 내보내기
CREATE TABLE IF NOT EXISTS `private_answers` (
  `private_question_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `answers` varchar(2000) NOT NULL,
  PRIMARY KEY (`private_question_id`),
  CONSTRAINT `FK_private_questions_TO_private_answers` FOREIGN KEY (`private_question_id`) REFERENCES `private_questions` (`private_question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.private_answers:~2 rows (대략적) 내보내기
/*!40000 ALTER TABLE `private_answers` DISABLE KEYS */;
INSERT INTO `private_answers` (`private_question_id`, `created_date`, `answers`) VALUES
	(2, '2019-11-25', '없어요//');
INSERT INTO `private_answers` (`private_question_id`, `created_date`, `answers`) VALUES
	(4, '2019-11-25', '대한통운입니다.');
/*!40000 ALTER TABLE `private_answers` ENABLE KEYS */;

-- 테이블 greenright.private_questions 구조 내보내기
CREATE TABLE IF NOT EXISTS `private_questions` (
  `private_question_id` int(11) NOT NULL AUTO_INCREMENT,
  `questIon_type` varchar(255) NOT NULL,
  `member_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `title` varchar(255) NOT NULL,
  `contents` varchar(2000) NOT NULL,
  `answer_tf` varchar(2500) DEFAULT '미답변',
  PRIMARY KEY (`private_question_id`),
  KEY `FK_members_TO_private_questions` (`member_id`),
  CONSTRAINT `FK_members_TO_private_questions` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.private_questions:~11 rows (대략적) 내보내기
/*!40000 ALTER TABLE `private_questions` DISABLE KEYS */;
INSERT INTO `private_questions` (`private_question_id`, `questIon_type`, `member_id`, `created_date`, `title`, `contents`, `answer_tf`) VALUES
	(1, '배송문의', 25, '2019-11-25', '언제 배송될까요?', '11월 18일 날 주문하였는데 아직까지 안왔어요.... 언제 오는거죠?\r\n빠른 답변 부탁드립니다.', '미답변');
INSERT INTO `private_questions` (`private_question_id`, `questIon_type`, `member_id`, `created_date`, `title`, `contents`, `answer_tf`) VALUES
	(2, '배송문의', 21, '2019-11-25', '배송현황은 어디서 확인할 수 있나요?', '너무너무 배송현황은 어디서 확인할 수 있나요???', '답변완료');
INSERT INTO `private_questions` (`private_question_id`, `questIon_type`, `member_id`, `created_date`, `title`, `contents`, `answer_tf`) VALUES
	(3, '판매문의', 27, '2019-11-25', '판매문의합니다', '판매자로 전환하려고 하는데 어느 곳에서 하는거죠?\r\n', '미답변');
INSERT INTO `private_questions` (`private_question_id`, `questIon_type`, `member_id`, `created_date`, `title`, `contents`, `answer_tf`) VALUES
	(4, '배송문의', 23, '2019-11-25', '배송업체는 어딘가요?', 'cj를 선호하는데 배송회사 딴회사라면 cj로 바꿔 주실수있나요?', '답변완료');
INSERT INTO `private_questions` (`private_question_id`, `questIon_type`, `member_id`, `created_date`, `title`, `contents`, `answer_tf`) VALUES
	(5, '판매문의', 23, '2019-11-25', '판매를 문의합니다.', '어떻게 판매권한을 획득하나요????', '미답변');
INSERT INTO `private_questions` (`private_question_id`, `questIon_type`, `member_id`, `created_date`, `title`, `contents`, `answer_tf`) VALUES
	(6, '상품문의', 23, '2019-11-25', '상품을문의합니다.', '어떻게 하면 좋은상품을획득할수있나요?????', '미답변');
INSERT INTO `private_questions` (`private_question_id`, `questIon_type`, `member_id`, `created_date`, `title`, `contents`, `answer_tf`) VALUES
	(7, '판매문의', 31, '2019-11-25', '업사이클링 쿠폰 수량 문의입니다.', '판매하는 업사이클링제품 쿠폰 수량 무제한 요청합니다.', '미답변');
INSERT INTO `private_questions` (`private_question_id`, `questIon_type`, `member_id`, `created_date`, `title`, `contents`, `answer_tf`) VALUES
	(8, '상품문의', 32, '2019-11-25', '상품문의합니다.', '업사이클링 제품의 경우 개인이 직접 만든 상품인건가요?', '미답변');
INSERT INTO `private_questions` (`private_question_id`, `questIon_type`, `member_id`, `created_date`, `title`, `contents`, `answer_tf`) VALUES
	(9, '상품문의', 32, '2019-11-25', '상품문의합니다.', '업사이클링 제품의 경우 개인이 직접 만든 상품인건가요?', '미답변');
INSERT INTO `private_questions` (`private_question_id`, `questIon_type`, `member_id`, `created_date`, `title`, `contents`, `answer_tf`) VALUES
	(10, '배송문의', 40, '2019-11-25', '배송현황파악이안됩니다.', '배송현황파악이안됩니다. 확인 후 알려주세요.', '미답변');
INSERT INTO `private_questions` (`private_question_id`, `questIon_type`, `member_id`, `created_date`, `title`, `contents`, `answer_tf`) VALUES
	(11, '배송문의', 46, '2019-11-26', '배송문의합니다.', '일주일이 지나도 오지 않습니다 ㅜㅜ 판매자에게 확인 부탁드립니다!', '미답변');
/*!40000 ALTER TABLE `private_questions` ENABLE KEYS */;

-- 테이블 greenright.products 구조 내보내기
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `registered_date` date NOT NULL,
  `diy_flag` tinyint(1) NOT NULL DEFAULT 0,
  `price` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `expiration_date` date DEFAULT NULL,
  `origin` varchar(255) DEFAULT NULL,
  `quantity` int(11) unsigned NOT NULL COMMENT '수량',
  `recommend_count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`product_id`),
  KEY `FK_sellers_TO_products` (`member_id`),
  KEY `FK_groups_TO_products` (`group_id`),
  CONSTRAINT `FK_groups_TO_products` FOREIGN KEY (`group_id`) REFERENCES `groups` (`group_id`),
  CONSTRAINT `FK_sellers_TO_products` FOREIGN KEY (`member_id`) REFERENCES `sellers` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.products:~45 rows (대략적) 내보내기
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(5, 18, 21, '2019-11-25', 1, 42900, '아람의자', ' 아라마/스툴의자모음/원목/보조의자/화장대의자', '1970-01-01', '한국', 1, 2);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(6, 11, 31, '2019-11-25', 0, 20000, '쌀눈', '맛있고 친환경적으로 만든 쌀눈입니다.', '2019-11-30', '한국', 100, 2);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(7, 11, 31, '2019-11-25', 0, 2900, '유기농 레몬에이드/콜라/아이스티', ' 유기농 레몬에이드/콜라/아이스티 입니다.', '2020-11-13', '벨기에', 200, 2);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(9, 18, 31, '2019-11-25', 1, 32000, '얼루어조명', ' 수들이 노력의 결실을 얻기 위해 밟고 섰던 메달 수여대의 나무판을 재활용해 만든 조명', '1970-01-01', '한국', 1, 6);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(11, 18, 31, '2019-11-25', 1, 12000, '에코팟', ' 커피 찌꺼기로 만든 화분입니다.', '1970-01-01', '한국', 0, 3);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(12, 12, 28, '2019-11-25', 0, 80000, '저지방 친환경 한우 찜갈비 선물세트 3kg', ' 고백한우 찜갈비 3kg 선물세트 입니다.', '2020-02-10', '국내', 0, 8);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(13, 18, 31, '2019-11-25', 1, 72000, '폐차의자', ' 폐차에 새로운 혁명을 불어넣은 자동차업사이클링 의자', '1970-01-01', '한국', 1, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(14, 18, 31, '2019-11-25', 1, 25000, '코카의자', ' 코카콜라로 만든 의자입니다.', '1970-01-01', '한국', 0, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(15, 18, 25, '2019-11-25', 1, 20000, '바퀴시계', '바퀴로 만든 시계입니다', '1970-01-01', '한국', 1, 2);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(16, 18, 28, '2019-11-25', 1, 128000, 'F421 SLEEVE FOR MACBOOK PRO 15_00145', '상품 설명\r\n별도의 내부 파우치가 있어 15인치 노트북 수납이 가능한 제품입니다.\r\n부착된 스트랩을 활용하여 토트 겸 숄더, 크로스 백으로 다양하게 사용 가능하며\r\n가방의 외부, 내부에 수납공간이 있어 소지품 보관이 편리합니다', '1970-01-01', '한국', 1, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(17, 11, 31, '2019-11-25', 0, 20000, '지리산 함양 고종시 곶감 건시 20입', '말랑쫄깃달콤', '2020-11-25', '경남 함양(지리산)', 0, 2);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(18, 10, 28, '2019-11-25', 0, 6200, '유기농 찰보리 1kg', ' 국산 유기농 찰보리입니다.', '2020-11-30', '국내', 100, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(19, 13, 25, '2019-11-25', 0, 599000, '레빗 퀸 침대', ' 최고급 침대', '2019-11-25', '이태리', 0, 8);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(20, 10, 28, '2019-11-25', 0, 7000, '유기농 당근 1kg', ' 국내산 유기농 당근입니다. ', '2019-12-11', '국내', 100, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(21, 12, 27, '2019-11-25', 0, 84000, '1++등급 등싱 3인분', ' 대관령 한우', '2019-12-25', '평창군', 10, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(22, 12, 27, '2019-11-25', 0, 56000, '1+등급 안심 2인분 600g', ' 안심하고 먹을 수 있는 안심~', '2019-12-25', '평창군', 10, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(23, 18, 34, '2019-11-25', 1, 186000, ' F553 LOU_00080', ' LOU\r\n지퍼가 달린 숄더 백 입니다.\r\n외부 포켓과 함께 가방 내부 두개의 포켓 나눠져 있어 수납에 용이하며,\r\n스트랩이 있어 체형에 맞게 길이 조절이 가능합니다.', '1970-01-01', '한국', 1, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(24, 12, 35, '2019-11-25', 0, 49000, '대관령 한우 보신 사골 2.5kg', ' 몸을 따뜻하게 할 땐 구수한 사골', '2019-12-04', '평창군', 10, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(25, 16, 31, '2019-11-25', 0, 72000, '마르세유 퀸체어', '마르세유 퀸체어입니다.', '2019-11-27', '한국', 50, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(26, 12, 35, '2019-11-25', 0, 50000, '양갈비 특가 1kg', ' 최고급 양갈비', '2019-12-18', '호주산', 10, 2);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(27, 16, 31, '2019-11-25', 0, 270000, '그레노 하퍼체어', '친환경 소재로 만든 거실 의자 세트입니다.', '2019-11-27', '한국', 50, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(28, 12, 35, '2019-11-25', 0, 22400, '한우 불고기', ' 세계인의 입맛을 사로잡은 불고기', '2019-12-18', '국내산', 10, 2);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(29, 12, 36, '2019-11-25', 0, 50000, '한우 육포', ' 씹을수록 고소하고 담백한 육포', '2020-11-19', '국내산', 10, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(30, 18, 34, '2019-11-25', 1, 382000, 'F155 CLAPTON_00039', ' F155 CLAPTON\r\n다양한 수납공간이 돋보이는 폴드형 백팩입니다.\r\n필요에 따라 18~22리터로 부피를 조절할 수 있습니다.\r\n어깨 스트랩에 3D메시 패딩을 사용하여\r\n땀 소비를 줄이고 마모에 있어 편안하게 착용이 가능합니다.', '1970-01-01', '한국', 1, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(31, 12, 36, '2019-11-25', 0, 22400, '한우 장조림', ' 최고의 반찬 장조림', '2019-11-30', '국내산', 11, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(32, 18, 34, '2019-11-25', 1, 128000, 'F271 MASIKURA_00060', ' MASIKURA\r\n작고 슬림한 물건들을 위한 파우치형 가방입니다.\r\n지퍼가 달린 두개의 수납 공간과 열쇠 고리를 포함하여 어깨에 걸고 잠그거나 두를 수 있는 좁은 끈이 있어\r\n클러치 또는 크로스백 두가지 형태로 활용이 가능합니다.', '1970-01-01', '한국', 1, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(33, 15, 31, '2019-11-25', 0, 371000, '모노디 테이블', ' 모노디 테이블입니다.', '2019-11-30', '한국', 100, 2);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(34, 11, 31, '2019-11-25', 0, 12000, '무농약 햇 수제 국화차', ' 내 마음 속에서 기품있게 피어난다', '2021-12-16', '대한민국', 10, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(36, 14, 31, '2019-11-25', 0, 2730000, '라무드 프라임 소파', ' 라무드 프라임 벨기에 워터릭 4-6인 라이트코너 소파', '2019-11-30', '한국', 100, 4);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(37, 11, 36, '2019-11-25', 0, 2850, '동결건조 딸기엔요거트', ' 아이들에게 정말 좋아요', '2020-11-19', '국산', 10, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(38, 11, 27, '2019-11-25', 0, 19900, '하루 포켓밀', '맛있고 몸에 좋은 포켓밀', '2020-12-23', '국산', 10, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(39, 17, 31, '2019-11-25', 0, 99000, '우피아 파티션', ' 우피아 파티션입니다.', '2019-11-30', '한국', 100, 2);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(40, 11, 27, '2019-11-25', 0, 3900, '달칩', ' 지금껏 느껴본 적 없는 바삭함', '2025-12-18', '국산', 10, 2);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(41, 13, 31, '2019-11-25', 0, 1150000, '밀레 호텔 평상형 침대', ' 밀레 호텔 평상형 침대입니다.', '2019-11-30', '한국', 100, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(42, 11, 37, '2019-11-25', 0, 2300, '유기농 사과떡튀밥', ' 어린이들의 취향저격!', '2020-11-13', '국산', 0, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(43, 18, 34, '2019-11-25', 1, 288000, 'F203 BOB_00175', ' BOB\r\n부착되어있는 스트랩을 활용하여 토트백 겸 숄더, 크로스 백으로 다양하게 사용 가능한 제품입니다.\r\n가방 외부에 부착된 토트 스트랩은 그립감이 뛰어나며, 내부에는 포켓이 있어 소지품 보관이 더욱 편리합니다.', '1970-01-01', '한국', 1, 2);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(44, 16, 31, '2019-11-25', 0, 60000, '의자삼둥이', ' 의자상둥이입니다.', '2019-11-30', '한국', 90, 5);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(45, 18, 34, '2019-11-25', 1, 128000, 'F52 MIAMI VICE_01132', ' MIAMI VICE\r\n다양한 디자인이 돋보이는 토트백입니다.\r\n스위스의 종이 쇼핑백에서 영감을 얻어 제작된 상품으로\r\n내부 공간이 넓어 다양한 소품을 넣고 다니실 수 있습니다.', '1970-01-01', '한국', 1, 0);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(46, 18, 38, '2019-11-25', 1, 120000, '우리둘이 체어', '우리둘이 체어입니다.', '1970-01-01', '한국', 1, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(47, 18, 37, '2019-11-25', 1, 55000, 'AL bag', '버려진 가죽으로 만든 멋드러진 Bag', '1970-01-01', '한국', 1, 0);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(48, 18, 39, '2019-11-25', 1, 21250, '자전거체인팔찌18', ' ', '1970-01-01', '한국', 1, 0);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(50, 13, 31, '2019-11-26', 0, 1100000, '툴페 침대', ' 툴페 침대입니다.', '2019-11-30', '한국', 0, 0);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(51, 13, 27, '2019-11-26', 0, 820000, '가죽 침대', ' 멋드러진 가죽 침대\r\n부드러운 감촉', '2019-11-30', '국내산', 10, 1);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(53, 1, 39, '2019-11-26', 0, 258000, 'LED일반서랍형침대', ' LED 일반 서랍형 침대', '2023-10-18', '국내', 50, 0);
INSERT INTO `products` (`product_id`, `group_id`, `member_id`, `registered_date`, `diy_flag`, `price`, `product_name`, `description`, `expiration_date`, `origin`, `quantity`, `recommend_count`) VALUES
	(55, 18, 31, '2019-11-26', 1, 50000, '체인시계', ' 폐자전거에 숨을 불어넣다.', '1970-01-01', '한국', 1, 0);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- 테이블 greenright.product_answers 구조 내보내기
CREATE TABLE IF NOT EXISTS `product_answers` (
  `product_question_id` int(11) NOT NULL AUTO_INCREMENT,
  `answer_contents` varchar(2000),
  `answer_created_date` date DEFAULT NULL,
  PRIMARY KEY (`product_question_id`),
  CONSTRAINT `FK_product_answers_product_questions` FOREIGN KEY (`product_question_id`) REFERENCES `product_questions` (`product_question_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.product_answers:~2 rows (대략적) 내보내기
/*!40000 ALTER TABLE `product_answers` DISABLE KEYS */;
INSERT INTO `product_answers` (`product_question_id`, `answer_contents`, `answer_created_date`) VALUES
	(1, '마시써요 ', '2019-11-25');
INSERT INTO `product_answers` (`product_question_id`, `answer_contents`, `answer_created_date`) VALUES
	(4, '234234', '2019-11-25');
/*!40000 ALTER TABLE `product_answers` ENABLE KEYS */;

-- 테이블 greenright.product_detail_photos 구조 내보내기
CREATE TABLE IF NOT EXISTS `product_detail_photos` (
  `product_detail_photos_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `product_detail_photopath` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`product_detail_photos_id`),
  KEY `FK_product_detail_photos_products` (`product_id`),
  CONSTRAINT `FK_product_detail_photos_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.product_detail_photos:~37 rows (대략적) 내보내기
/*!40000 ALTER TABLE `product_detail_photos` DISABLE KEYS */;
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(1, 5, '6e30f610-ffe2-4db8-9f37-4a1c90940418');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(2, 5, '6f6a1c0d-c886-4b54-9a5f-9a1d13095de1');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(3, 5, '9190892e-548e-4dbb-b8ff-54e425fe3cf4');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(4, 6, 'b09f5643-a204-4cdf-a0f2-7c3d69c75680');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(5, 7, '0c65cf8e-fbae-4326-a244-5e91d6e4fd12');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(10, 12, '348816ca-8757-43eb-9414-b2984fd3618a');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(11, 16, '861a9a57-103d-4227-9617-f0a18aed4e9c');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(12, 16, '3945743f-4d2c-40d6-92e4-c9a70cda8087');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(13, 16, 'b9dd0acd-ec81-452b-9c65-103251a238e9');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(14, 17, 'ba3689cc-7b5f-4f22-b287-ddefaef7e6cc');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(15, 17, '1388d2ba-c206-408a-9c7c-80b2326574a3');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(16, 18, '16105658-7318-45fe-99f3-87adc0a65054');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(17, 18, '533b6c07-eb94-42b4-909f-fe30b5183e60');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(18, 18, '81b2ffa1-88fd-4d8e-a90e-9b9433bd29dd');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(19, 19, 'a1b5113b-5351-42c0-85a5-18935c669bcc');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(20, 19, 'bbff3f9c-0592-491e-8be9-aa76529831e5');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(21, 19, '774d611d-f479-473a-87e9-7022f9f3deb8');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(22, 19, '1caf0ca7-e873-4fb9-ac42-1f0c5e802a2a');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(23, 19, '47506b87-812c-42c8-ba99-e7afac45940c');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(24, 19, '5a2db84a-b490-45c7-8111-6dfd98927c54');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(25, 19, '69fac00f-c159-4418-b20c-42848f2da5cb');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(26, 19, '4cd5f825-8dbe-48c8-ac76-b63ee2b03e27');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(27, 19, '7bf1ed8f-b587-4891-be41-4ff455a05009');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(28, 20, '23b8961e-ca06-4e00-a655-61ee7f38fa14');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(29, 20, 'fc64024f-5b70-4a18-832d-0dc050ca1da6');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(30, 23, '14fc2554-ea72-4df7-83c0-11c58f9a7e1e');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(31, 23, '787370c0-09df-41ce-a49c-61ed485a0274');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(32, 23, 'a2c2a193-0ba4-4ad4-90b6-1095e3f35ad2');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(33, 30, 'c3ed9e9a-c039-416c-81ed-2cf8c7d85747');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(34, 30, 'e75650ed-87c9-4601-b8fe-08fd8cc73530');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(35, 32, '3de3fee5-aa48-4263-b36b-0e92982e9248');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(36, 32, '9e4c5231-11c3-43dd-9a12-12c25296087c');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(37, 43, '9ea64d5e-abc4-471f-bd22-9d0376cd724a');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(38, 43, '9c9a560e-7774-42e1-bafe-5e110fc3ae96');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(39, 45, '60fb2172-8500-4cbe-91be-3596dbb67c39');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(40, 45, '7751151c-f45d-42b9-81ed-afcada348497');
INSERT INTO `product_detail_photos` (`product_detail_photos_id`, `product_id`, `product_detail_photopath`) VALUES
	(41, 48, 'c6a176b0-90db-4836-81bf-82c7e0e8dbc2');
/*!40000 ALTER TABLE `product_detail_photos` ENABLE KEYS */;

-- 테이블 greenright.product_photos 구조 내보내기
CREATE TABLE IF NOT EXISTS `product_photos` (
  `product_photo_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `photo_path` varchar(255) NOT NULL,
  `main_photo_flag` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_photo_id`),
  UNIQUE KEY `UIX_product_photos` (`photo_path`),
  KEY `FK_products_TO_product_photos` (`product_id`),
  CONSTRAINT `FK_products_TO_product_photos` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.product_photos:~70 rows (대략적) 내보내기
/*!40000 ALTER TABLE `product_photos` DISABLE KEYS */;
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(3, 5, 'a572238d-a847-4bec-986b-0b2895c01430', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(4, 5, '834fb673-94dc-4a16-8f62-0148d8db71a1', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(5, 5, 'e5739c13-82b7-42f4-949e-e1ae4d3247c1', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(6, 6, '341aa1bf-efe0-4f87-b7b1-79d23a221776', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(7, 7, '15953d3f-a96e-471c-9db3-cf48b261653b', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(12, 9, 'a3aafbf9-9048-4fdd-96f0-25bdf3479bd9', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(13, 9, '260fca15-51b3-4c06-9dda-900f2af837c1', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(18, 11, '83cb9ea4-9452-482c-9581-d8668cf8b611', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(23, 12, 'd02b63a1-1599-4bde-b496-e7bb5441c49b', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(24, 13, '85d22584-db9c-4d7f-8117-ea40eb6064b7', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(25, 14, '63d5a337-7137-4aad-a6d6-966ba1afbb0f', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(26, 15, '082cd226-9c82-4e78-abce-140751614368', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(27, 16, 'd4cf692e-b03f-4961-856b-e04476bee82e', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(28, 16, '2597cec3-27f7-485f-aa6e-b0df63cbc4b3', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(29, 17, 'f279ea93-4fff-41db-8f9d-d3716fe7c209', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(30, 14, '9e8134c9-cd54-4e6d-b99f-6b360664bc66', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(31, 14, '4b4ca22f-04dc-454d-a80c-b72d67f595c9', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(32, 11, '0a02d0b5-0735-4d41-adf3-37e686417614', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(33, 11, '4fa1c3c2-1db2-4e4a-80b1-a3bbb4ce2093', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(34, 18, 'a8f7aa8e-d7ba-4fe5-8971-dcc1a0301aae', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(35, 19, 'ae6575ec-8c17-49d6-a7d8-10de2503eb6c', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(36, 20, 'e3e84fab-c546-4347-b0c2-40c84d06196e', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(37, 21, 'ba6d9c23-373a-4f72-b40d-012b68ad502d', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(38, 22, '9e083edb-d311-4ea3-9bc3-0bc785325774', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(39, 23, 'ddc8e99e-fee4-4ccb-9d55-532a5f974235', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(40, 23, 'd52cc165-44b2-45ad-b68c-307ae8ecb4f2', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(41, 24, 'cd622ad2-0d05-4fb2-af32-49ac36ee4c43', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(42, 25, 'cafc346d-33ef-415b-b699-f220a8ea7237', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(43, 26, '183be18b-cb30-4288-9717-6ca379199304', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(44, 27, '2c13e1db-e544-414c-b5de-c67046a3c8e6', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(45, 28, 'd4e50e33-12cb-4f15-8945-99a312341b5a', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(46, 29, '5381297c-5dab-418a-952c-d6af7a0d73f7', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(47, 30, '3c411e5e-22d0-471e-92a9-6161c0827902', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(48, 30, '3513c2c5-f1ee-4fed-8f9d-f9567509515a', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(49, 31, 'af13f4c6-0b76-4b28-831e-87464eb6fe3f', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(50, 32, '453bd17a-f133-4231-9214-4ac9bac2d017', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(51, 32, '5078554a-572b-494f-b269-d65991c8d47e', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(52, 32, 'ca906dc4-3a6f-4dc6-8f1b-de27da7d174c', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(53, 32, '4520b775-d0bd-4221-b4fc-0de5df013a59', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(54, 33, 'db43c4c7-970c-47d7-bea6-a1c09ec65054', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(55, 34, '2ccbb475-de63-4343-b5bd-4db1375114a1', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(56, 36, 'fa479e87-173b-4b04-a436-7e4f78c79b76', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(57, 37, 'a410fd9a-e85a-4104-a97d-66cc2ee8c57b', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(58, 38, '7f701d87-f4c9-47dc-8cc7-1df7954b3721', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(59, 39, '0620e8c3-e6e6-4649-96ae-0d213e79e748', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(60, 40, 'a3b1ebf8-743c-455f-8fee-3925e4de2db6', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(61, 41, '740beb20-d1a9-4e33-a3d4-65ea00796639', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(63, 43, '17d05ba5-7d40-437b-b74d-e36ed983e52d', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(64, 43, '3ea17550-2bdc-43d0-92b6-9e852e94fa55', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(65, 43, '7cafec9d-8166-4d83-9305-99968496676f', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(66, 43, '62515746-4b40-43be-a8b0-a428cfff5d19', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(67, 42, '37ecaa3f-fef1-4455-8aa2-8ba93bcc49ce', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(68, 44, '30f04bab-27c8-4fa8-9167-bc6e54269716', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(69, 45, '02e5bed9-107d-483d-b95d-938b8e885c0b', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(70, 45, '1596ba5a-5725-4793-b75d-69fcb04e48e6', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(71, 45, '623fddd7-19b8-4417-a1d4-d04e27b0b941', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(72, 45, '40c4c34f-8d4a-4cf0-bba9-3e7324edbaa9', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(73, 45, 'b0a692c0-b270-4bc0-a992-bb9dbaa82662', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(74, 45, 'bdca048e-2163-41e1-91b5-964bf5d6a76d', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(75, 46, 'b80e2ec8-201f-4ab7-b82a-e078943f84bd', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(76, 47, '50fa7892-7807-4707-bf80-6fb9d6add4b5', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(77, 48, 'ecae4c40-8cb1-44a1-9304-e56aed5d87f5', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(79, 12, 'edbdeff2-b6e6-46c7-b895-626b494616f8', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(80, 12, '8bbc0887-cde2-44bb-b5ac-b595c8c3d045', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(81, 12, 'b6afa75a-b9a4-4f72-9544-ff7af7704734', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(82, 19, 'ad1ba766-cfd1-4bb8-8610-513f065a62fc', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(83, 50, 'bf255ad9-a4b4-42da-abe3-7402a7eca725', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(84, 51, '8f8f6e51-26cd-48e1-a80a-e0185d150c03', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(85, 53, '48cd9be2-5596-4ba9-956c-98a2dc3d30fc', 0);
INSERT INTO `product_photos` (`product_photo_id`, `product_id`, `photo_path`, `main_photo_flag`) VALUES
	(87, 55, '01a39878-2be8-4ed9-9562-a812ce711258', 0);
/*!40000 ALTER TABLE `product_photos` ENABLE KEYS */;

-- 테이블 greenright.product_questions 구조 내보내기
CREATE TABLE IF NOT EXISTS `product_questions` (
  `product_question_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `secret_flag` tinyint(1) NOT NULL,
  `title` varchar(255) NOT NULL,
  `contents` varchar(2000) NOT NULL,
  PRIMARY KEY (`product_question_id`),
  KEY `FK_members_TO_product_questions` (`member_id`),
  KEY `FK_products_TO_product_questions` (`product_id`),
  CONSTRAINT `FK_members_TO_product_questions` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`),
  CONSTRAINT `FK_products_TO_product_questions` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.product_questions:~5 rows (대략적) 내보내기
/*!40000 ALTER TABLE `product_questions` DISABLE KEYS */;
INSERT INTO `product_questions` (`product_question_id`, `member_id`, `product_id`, `created_date`, `secret_flag`, `title`, `contents`) VALUES
	(1, 23, 6, '2019-11-25', 0, '쌀눈 맛있나요??', '궁금하네요');
INSERT INTO `product_questions` (`product_question_id`, `member_id`, `product_id`, `created_date`, `secret_flag`, `title`, `contents`) VALUES
	(3, 23, 6, '2019-11-25', 1, '쌀눈대용량 구매가능?', '??');
INSERT INTO `product_questions` (`product_question_id`, `member_id`, `product_id`, `created_date`, `secret_flag`, `title`, `contents`) VALUES
	(4, 40, 12, '2019-11-25', 0, '추가입고 언제되나요??', '추가입고 언제되나요??');
INSERT INTO `product_questions` (`product_question_id`, `member_id`, `product_id`, `created_date`, `secret_flag`, `title`, `contents`) VALUES
	(5, 44, 19, '2019-11-26', 1, '배송문의', '배송기간이 어떻게 되나요?');
INSERT INTO `product_questions` (`product_question_id`, `member_id`, `product_id`, `created_date`, `secret_flag`, `title`, `contents`) VALUES
	(6, 46, 12, '2019-11-26', 0, '배송기간이 어떻게 되나요?', '내일 받을 수 있나요?');
/*!40000 ALTER TABLE `product_questions` ENABLE KEYS */;

-- 테이블 greenright.recommends 구조 내보내기
CREATE TABLE IF NOT EXISTS `recommends` (
  `boards_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  PRIMARY KEY (`boards_id`,`member_id`),
  KEY `FK_members_TO_recommends` (`member_id`),
  CONSTRAINT `FK_boards_TO_recommends` FOREIGN KEY (`boards_id`) REFERENCES `boards` (`boards_id`),
  CONSTRAINT `FK_members_TO_recommends` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.recommends:~7 rows (대략적) 내보내기
/*!40000 ALTER TABLE `recommends` DISABLE KEYS */;
INSERT INTO `recommends` (`boards_id`, `member_id`) VALUES
	(4, 23);
INSERT INTO `recommends` (`boards_id`, `member_id`) VALUES
	(6, 23);
INSERT INTO `recommends` (`boards_id`, `member_id`) VALUES
	(6, 26);
INSERT INTO `recommends` (`boards_id`, `member_id`) VALUES
	(7, 23);
INSERT INTO `recommends` (`boards_id`, `member_id`) VALUES
	(8, 23);
INSERT INTO `recommends` (`boards_id`, `member_id`) VALUES
	(8, 25);
INSERT INTO `recommends` (`boards_id`, `member_id`) VALUES
	(10, 39);
/*!40000 ALTER TABLE `recommends` ENABLE KEYS */;

-- 테이블 greenright.reviews 구조 내보내기
CREATE TABLE IF NOT EXISTS `reviews` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `rating` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `contents` varchar(2000) NOT NULL,
  PRIMARY KEY (`review_id`),
  KEY `FK_members_TO_reviews` (`member_id`),
  KEY `FK_products_TO_reviews` (`product_id`),
  CONSTRAINT `FK_members_TO_reviews` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`),
  CONSTRAINT `FK_products_TO_reviews` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.reviews:~13 rows (대략적) 내보내기
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` (`review_id`, `product_id`, `member_id`, `created_date`, `rating`, `title`, `contents`) VALUES
	(1, 5, 21, '2019-11-25', 4, '좋은상품 잘쓰겠습니다.', '좋은상품 잘쓰겠습니다.');
INSERT INTO `reviews` (`review_id`, `product_id`, `member_id`, `created_date`, `rating`, `title`, `contents`) VALUES
	(2, 5, 21, '2019-11-25', 5, '판매 잘해주세여!', '판매 잘해주세여!!');
INSERT INTO `reviews` (`review_id`, `product_id`, `member_id`, `created_date`, `rating`, `title`, `contents`) VALUES
	(9, 6, 23, '2019-11-25', 5, '인생 최고의 쌀눈입니다...', '동생몰래 먹다가 동생한테 걸려서 싸웠습니다. ');
INSERT INTO `reviews` (`review_id`, `product_id`, `member_id`, `created_date`, `rating`, `title`, `contents`) VALUES
	(10, 12, 40, '2019-11-25', 4, '잘먹겠습니다!!', '너무 맛있어요 ㅎㅎ');
INSERT INTO `reviews` (`review_id`, `product_id`, `member_id`, `created_date`, `rating`, `title`, `contents`) VALUES
	(11, 12, 27, '2019-11-26', 4, '고기가 너무 야들야들 맛있어요', '고기 질이 너무 좋아서 맘에 드네요.\n그리고 빠른 배송 정말 굳입니다~~~');
INSERT INTO `reviews` (`review_id`, `product_id`, `member_id`, `created_date`, `rating`, `title`, `contents`) VALUES
	(12, 19, 38, '2019-11-26', 5, '혼수침대용으로 깔끔하고 좋습니다 ! ', '혼수침대용으로 깔끔하고 좋습니다 ! !!!');
INSERT INTO `reviews` (`review_id`, `product_id`, `member_id`, `created_date`, `rating`, `title`, `contents`) VALUES
	(13, 12, 34, '2019-11-26', 4, '오늘의 밥도둑!!', '또 살거에요!');
INSERT INTO `reviews` (`review_id`, `product_id`, `member_id`, `created_date`, `rating`, `title`, `contents`) VALUES
	(14, 12, 38, '2019-11-26', 5, '재구매 합니다 ^^', '아이들이 너무 잘먹어요 ㅎㅎ');
INSERT INTO `reviews` (`review_id`, `product_id`, `member_id`, `created_date`, `rating`, `title`, `contents`) VALUES
	(15, 19, 34, '2019-11-26', 4, '렛빗 퀸 침대에서 나갈수가 없게되었습니다!', '너무 좋아요');
INSERT INTO `reviews` (`review_id`, `product_id`, `member_id`, `created_date`, `rating`, `title`, `contents`) VALUES
	(16, 12, 21, '2019-11-26', 4, '아이들이 너무 잘먹어요 ㅎㅎ', '아이들이 너무 잘먹어요 ㅎㅎ');
INSERT INTO `reviews` (`review_id`, `product_id`, `member_id`, `created_date`, `rating`, `title`, `contents`) VALUES
	(17, 19, 21, '2019-11-26', 4, '하루종일 침대에 있었어요 : )', '하루종일 침대에 있었어요 : )');
INSERT INTO `reviews` (`review_id`, `product_id`, `member_id`, `created_date`, `rating`, `title`, `contents`) VALUES
	(18, 19, 39, '2019-11-26', 4, '너무 좋아서 아이들 방에도 놔줬어요', '추천합니다.');
INSERT INTO `reviews` (`review_id`, `product_id`, `member_id`, `created_date`, `rating`, `title`, `contents`) VALUES
	(19, 12, 46, '2019-11-26', 5, '고기가 너무 야들야들해요!', '아이들이 맛있게 먹어요 ㅎㅎ');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;

-- 테이블 greenright.review_photos 구조 내보내기
CREATE TABLE IF NOT EXISTS `review_photos` (
  `review_photo_id` int(11) NOT NULL AUTO_INCREMENT,
  `review_id` int(11) NOT NULL,
  `photo_path` varchar(255) NOT NULL,
  PRIMARY KEY (`review_photo_id`),
  UNIQUE KEY `UIX_review_photos` (`photo_path`),
  KEY `FK_reviews_TO_review_photos` (`review_id`),
  CONSTRAINT `FK_reviews_TO_review_photos` FOREIGN KEY (`review_id`) REFERENCES `reviews` (`review_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.review_photos:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `review_photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_photos` ENABLE KEYS */;

-- 테이블 greenright.review_replies 구조 내보내기
CREATE TABLE IF NOT EXISTS `review_replies` (
  `review_reply_id` int(11) NOT NULL AUTO_INCREMENT,
  `review_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `contents` varchar(2000) NOT NULL,
  PRIMARY KEY (`review_reply_id`),
  KEY `FK_reviews_TO_review_replies` (`review_id`),
  KEY `FK_members_TO_review_replies` (`member_id`),
  CONSTRAINT `FK_members_TO_review_replies` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`),
  CONSTRAINT `FK_reviews_TO_review_replies` FOREIGN KEY (`review_id`) REFERENCES `reviews` (`review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.review_replies:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `review_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_replies` ENABLE KEYS */;

-- 테이블 greenright.sellers 구조 내보내기
CREATE TABLE IF NOT EXISTS `sellers` (
  `member_id` int(11) NOT NULL,
  `bank_name` varchar(50) NOT NULL,
  `account_num` varchar(50) NOT NULL,
  `account_holder` varchar(50) NOT NULL,
  `tel` varchar(50) NOT NULL,
  `point` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `UIX_sellers2` (`tel`),
  UNIQUE KEY `UIX_sellers` (`account_num`),
  CONSTRAINT `FK_members_TO_sellers` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.sellers:~16 rows (대략적) 내보내기
/*!40000 ALTER TABLE `sellers` DISABLE KEYS */;
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(1, '국민은행', '51710201285328', '이원주', '01033081595', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(10, '국민은행', '517102012853284', '이원주', '01033081594', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(19, '국민은행', '51111111111111111111', '이원주', '01099999999', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(21, '국민은행', '110082207866', '이용재', '07035148864', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(23, '신한은행', '3333074408814', '최태훈', '01000000048', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(25, '농협은행', '22113451068021', '김지수', '01056891424', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(27, '농협은행', '22113451068025', '김종현', '01056847514', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(28, '농협', '55644342440', '박그린', '01022222323', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(31, '신한은행', '221354784212', '김윤재', '0317543315', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(33, '신한은행', '110338040229', '김그린', '0317186423', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(34, '농협', '45678325554', '김삼룡', '01098567513', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(35, '외환은행', '22113451068596', '곽아론', '01089753424', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(36, '국민은행', '22113451068156', '강동호', '01084895471', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(37, '농협은행', '110082207864', '지현준', '01056844521', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(38, '신한은행', '02155319645', '이효진', '027188832', 0);
INSERT INTO `sellers` (`member_id`, `bank_name`, `account_num`, `account_holder`, `tel`, `point`) VALUES
	(39, '농협', '47854512354', '김춘자', '01036691125', 0);
/*!40000 ALTER TABLE `sellers` ENABLE KEYS */;

-- 테이블 greenright.upcycling_recommend 구조 내보내기
CREATE TABLE IF NOT EXISTS `upcycling_recommend` (
  `member_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`member_id`,`product_id`),
  KEY `FK__products` (`product_id`),
  CONSTRAINT `FK__members` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`),
  CONSTRAINT `FK__products` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 greenright.upcycling_recommend:~6 rows (대략적) 내보내기
/*!40000 ALTER TABLE `upcycling_recommend` DISABLE KEYS */;
INSERT INTO `upcycling_recommend` (`member_id`, `product_id`) VALUES
	(23, 19);
INSERT INTO `upcycling_recommend` (`member_id`, `product_id`) VALUES
	(27, 9);
INSERT INTO `upcycling_recommend` (`member_id`, `product_id`) VALUES
	(27, 19);
INSERT INTO `upcycling_recommend` (`member_id`, `product_id`) VALUES
	(34, 12);
INSERT INTO `upcycling_recommend` (`member_id`, `product_id`) VALUES
	(34, 19);
INSERT INTO `upcycling_recommend` (`member_id`, `product_id`) VALUES
	(34, 36);
/*!40000 ALTER TABLE `upcycling_recommend` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
